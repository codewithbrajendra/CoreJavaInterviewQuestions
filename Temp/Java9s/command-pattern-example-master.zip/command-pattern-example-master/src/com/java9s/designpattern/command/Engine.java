package com.java9s.designpattern.command;

public class Engine {
	public void speedUP(){
		System.out.println("Speeding up the engine");
	}
	
	public void slowDOWN(){
		System.out.println("Slow down the engine");
	}
}
