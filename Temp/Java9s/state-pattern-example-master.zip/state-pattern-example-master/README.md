# state-pattern-example
State Pattern example in Java by Java9.com
