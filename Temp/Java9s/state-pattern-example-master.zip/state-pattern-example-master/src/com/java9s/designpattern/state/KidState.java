package com.java9s.designpattern.state;

public interface KidState {
	public void play();
	
	public void eat();
}
