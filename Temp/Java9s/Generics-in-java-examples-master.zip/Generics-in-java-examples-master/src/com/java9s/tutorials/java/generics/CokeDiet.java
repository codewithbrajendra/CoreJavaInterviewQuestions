package com.java9s.tutorials.java.generics;

public class CokeDiet extends Coke {

}
