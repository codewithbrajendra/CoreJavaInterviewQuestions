package com.java9s.tutorials.java.generics;

public class CokeGreen extends Coke{

}
