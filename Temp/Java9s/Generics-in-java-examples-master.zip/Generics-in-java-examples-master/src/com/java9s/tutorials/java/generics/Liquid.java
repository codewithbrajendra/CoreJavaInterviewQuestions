package com.java9s.tutorials.java.generics;

public interface Liquid {

}
