package com.java9s.tutorials.java.generics;

public class Glass2 <T extends  Juice & Liquid >{

}
