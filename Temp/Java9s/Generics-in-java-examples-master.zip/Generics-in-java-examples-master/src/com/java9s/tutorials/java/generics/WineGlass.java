package com.java9s.tutorials.java.generics;

public class WineGlass<T> extends Glass<T> {

}
