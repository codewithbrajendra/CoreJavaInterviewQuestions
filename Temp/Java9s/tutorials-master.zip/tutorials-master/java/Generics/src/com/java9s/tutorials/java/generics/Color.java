package com.java9s.tutorials.java.generics;

public class Color<R,G,B> {

}
