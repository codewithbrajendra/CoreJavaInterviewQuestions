package com.java9s.tutorials.designpattern.adapter;

public interface Customer {
	public String getName();
	public int getAge();
	public Address getAddress();
}
