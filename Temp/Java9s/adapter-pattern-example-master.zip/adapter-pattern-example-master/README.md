# adapter-pattern-example
Adapter design pattern example in java - java9s.com
