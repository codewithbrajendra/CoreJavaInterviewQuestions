# proxy-pattern-example
A proxy pattern example in Java
