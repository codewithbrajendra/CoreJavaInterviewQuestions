package com.java9s.tutorials.designpattern.proxy;

public interface ISP {
	public String getResource(String site);
}
