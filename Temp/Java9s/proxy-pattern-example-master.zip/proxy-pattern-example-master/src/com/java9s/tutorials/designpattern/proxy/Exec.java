package com.java9s.tutorials.designpattern.proxy;

public class Exec {
	public static void main(String[] args) {
		Browser browser = new Browser();
		browser.sendRequest();
	}
}
