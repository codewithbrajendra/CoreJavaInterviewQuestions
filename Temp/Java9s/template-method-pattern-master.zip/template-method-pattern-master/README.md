# template-method-pattern

A template method pattern in java example
