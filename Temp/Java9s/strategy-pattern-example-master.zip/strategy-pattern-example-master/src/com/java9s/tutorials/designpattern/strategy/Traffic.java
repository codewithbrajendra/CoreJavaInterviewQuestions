package com.java9s.tutorials.designpattern.strategy;

public enum Traffic {
	HIGH_TRAFFIC,
	LOW_TRAFFIC;
}
