package com.java9s.tutorials.designpattern.strategy;

public class Exec {
	public static void main(String[] args) {
		Navigation navigation = new Navigation();
		navigation.navigate();
	}
}
