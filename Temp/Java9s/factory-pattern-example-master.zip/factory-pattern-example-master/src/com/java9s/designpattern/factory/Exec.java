package com.java9s.designpattern.factory;

public class Exec {
	 public static void main(String[] args) {
		Mobile mobile = MobileFactory.createMobile(Mobile.SAMSUNG);

	}
}
